from django.shortcuts import render, get_object_or_404
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from .models import Event
from .forms import EventForm,UpdateForm
from django.urls import reverse_lazy, reverse
from django.http import HttpResponseRedirect


def BookView(request, pk):
    post = get_object_or_404(Event, id=request.POST.get('event_id'))
    post.book.add(request.user)
    post.available -= 1
    return HttpResponseRedirect(reverse('event-details', args=[str(pk)]))
    
    


class HomeView(ListView):
    model = Event
    template_name = 'home.html'


def CategoryView(request, cats):
    category_event = Event.objects.filter(category=cats)
    return render(request, 'categories.html',{'cats':cats, 'category_event':category_event})

class EventDetailView(DetailView):
    model = Event
    template_name = 'detail.html'

    def get_context_data(self,*args, **kwargs):
        context = super(EventDetailView, self).get_context_data(**kwargs)
        
        stuff = get_object_or_404(Event, id=self.kwargs['pk'])
        total_register = stuff.total_register()
        available_seats = stuff.available_seats()
        context["total_register"] = total_register
        context["available_seats"] = available_seats
        return context
    

class AddEventView(CreateView):
    model = Event
    form_class = EventForm
    template_name = "add_event.html"
    #fields = "__all__"
    

class UpdateEventView(UpdateView):
    model = Event
    template_name = 'edit_event.html'
    form_class = UpdateForm
    #fields = ['name','thumbnail','venue','desc','available']


class DeleteEventView(DeleteView):
    model = Event
    template_name = "delete_event.html"
    success_url = reverse_lazy("home")