from django.urls import path
from .views import HomeView,EventDetailView,AddEventView,UpdateEventView,DeleteEventView,CategoryView,BookView


urlpatterns = [
    path('', HomeView.as_view(), name="home"),
    path('event/<int:pk>', EventDetailView.as_view(),name="event-details"),
    path('addevent/', AddEventView.as_view(),name="add-event"),
    path('event/edit/<int:pk>', UpdateEventView.as_view(), name="update_event"),
    path('event/<int:pk>/remove', DeleteEventView.as_view(), name="delete_event"),
    path('category/<str:cats>/', CategoryView, name="category"),
    path('book/<int:pk>', BookView, name="book_event"),
]
