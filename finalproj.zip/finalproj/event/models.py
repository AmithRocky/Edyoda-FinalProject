from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse

class Category(models.Model):
    name = models.CharField(max_length=250)

    def __str__(self):
        return self.name


    def get_absolute_url(self):
        return reverse("home")




class Event(models.Model):
    name = models.CharField(max_length=250)
    organizer = models.ForeignKey(User, on_delete=models.CASCADE)
    thumbnail = models.TextField()
    venue = models.CharField(max_length=250)
    desc = models.TextField()
    category = models.CharField(max_length=250,default='Technology')
    date = models.DateTimeField(auto_now=False, auto_now_add=True)
    available = models.IntegerField(default=0)
    book = models.ManyToManyField(User, related_name='book_event')

    def total_register(self):
        return self.book.count()
    
    def available_seats(self):
        total_reg = self.available - self.book.count()
        return total_reg


    def __str__(self):
        return self.name + ' | ' + str(self.organizer) 
    

    def get_absolute_url(self):
        return reverse("home")
    


